
const express=require('express');
const authRouter = express.Router();

const authorsdata=require('../model/authorsdata')

function router(nav){


    // var authors = [
    //     {
    //         //title:'tom and jerry',
    //         author:'joseph barbera',
    //         //genre:'cartoon',
    //         img:"tom.png"
    //     },
    //     {
    //        // title:'harry potter',
    //         author:'J K Rowling',
    //        // genre:'fantasy',
    //         img:"harry.jfif"
    //     },
    //     {
    //        // title:'paathummayude aadu',
    //         author:'vaikom muhammed basheer',
    //        // genre:'drama',
    //         img:"basheer.jfif"
    //     }
    // ]
    
    authRouter.get('/',function(req,res){
            authorsdata.find()
            .then(function(authors){
        res.render("authors",
            {
                nav,
                title:'Library',
                authors
            });
        
        });
    });
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
    authRouter.get('/:id',function(req,res){
        const id=req.params.id
        .then(function(authors){
        res.render('author',{
            nav,
                title:'Library',
                authors
      
    
        });
    });

    });

authRouter.post('/addauthor',function(req,res){
    
        res.render("addauthor",
            {
                nav,
                title:'Library',
                
            });
        
        });
    

    authRouter.post('/authorspage',function(req,res){
        var item={

        
        author:req.body.author,
        
        image:req.body.image
        }

       var author=authorsdata(item) 
        author.save();//saving to db
        res.redirect('/authors');
     });


    authRouter.post('/delete',function(req,res){
        const id=req.body.id;
    authorsdata.deleteOne({_id:id})
    .then(function(){
            // res.render("books",{
            //     nav,
            //     title:"books",
            //     book
            res.redirect('/authors');
    
       });
        
      //  })

// 
});

authRouter.post('/edit',function(req,res){
    const id=req.body.id;
   
    authorsdata.findOne({_id:id})
    .then(function(authors){


        res.render('editauthor',{
            nav,
            title:'edit book',
            authors
  

    });

    })
   
});

authRouter.post('/update',function(req,res){
    var item={
        
        author:req.body.author,
        
        image:req.body.image
    }
    var update=authorsdata.findByIdAndUpdate(req.body.id,item);
    update.exec(function(err,data){
        if(err) throw err;
        authorsdata.find()
        .then(function(authors){
            res.render("authors",{
                nav,
                title:"authors",
                authors
            })
        })
    })
})







    return authRouter;
}



module.exports = router;