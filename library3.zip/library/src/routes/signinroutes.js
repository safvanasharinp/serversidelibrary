
const express=require('express');
const signin1Router = express.Router();

const signupdata=require('../model/signupdata')
const signindata=require('../model/signindata')
function router(nav){
    
    signin1Router.get('/',function(req,res){
    
        res.render("signin1");
            
        
        })
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
    // authRouter.get('/:id',function(req,res){
    //     const id=req.params.id
    //     res.render('book',{
    //         nav,
    //             title:'Library',
    //             book:books[id]
      
    
    //     });
    // });

    signin1Router.post('/in',function(req,res){
         var item={
             authority1:req.body.authority,
            email1:req.body.email,
         phone1:req.body.phone,
         psw:req.body.psw
         }
   // signupdata.findOne({"email":email1})
        var signup= signupdata(item);
        signindata.findOne({authority:signup.authority,email1:signup.email,phone1:signup.phone,psw:signup.psw}),function(err)
        {
            if(err){
                alert("error occoured!");
            }
        }
   
      
        res.redirect('/books');
// 
});
        
    return signin1Router;
}



module.exports = router;