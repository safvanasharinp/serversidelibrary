const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/library');
const Schema=mongoose.Schema;


const signupschema=new Schema({
    authority:String,
    email:String,
    phone:String,
    psw:String,
    pswrepeat:String
});

var signupdata=mongoose.model('signupdata',signupschema);

module.exports=signupdata;