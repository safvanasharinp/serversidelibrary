const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/library');
const Schema=mongoose.Schema;


const authorschema=new Schema({
    
    author:String,
    
    image:String
});

var authorsdata=mongoose.model('authorsdata',authorschema);

module.exports=authorsdata;