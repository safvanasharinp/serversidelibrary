const express=require('express');

const app= new express;

const nav=[
    {
        link:'/home',name:'HOME'
    },
    {
        link:'/books',name:'BOOKS'
    },
    {
        link:'/authors',name:'AUTHORS'
    },
    {
        link:'/addbooks',name:'ADD BOOK'
    },
    {
        link:'/signup1',name:'SIGNUP'
    },
    {
        link:'/signin1',name:'SIGNIN'
    }

];
// const buttons=[
    

// ];
const booksRouter=require('./src/routes/bookroutes')(nav)
const signup1Router=require('./src/routes/signuproutes')(nav)
const signin1Router=require('./src/routes/signinroutes')(nav)
const authRouter=require('./src/routes/authroutes')(nav)
const homeRouter=require('./src/routes/homeroutes')(nav)
const addbooksRouter=require('./src/routes/addbooksroutes')(nav)
app.use(express.static('./public'));

app.set('view engine','ejs');
app.set('views','./src/views');
app.use('/books',booksRouter);
app.use('/authors',authRouter);
app.use('/signup1',signup1Router);
app.use('/signin1',signin1Router);
app.use('/home',homeRouter);
app.use('/addbooks',addbooksRouter);


app.get('/',function(req,res){

res.render("index",
    {
        nav,
        title:'Library',
        
    });

});
 


app.listen(3000);