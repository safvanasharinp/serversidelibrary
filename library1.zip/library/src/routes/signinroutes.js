
const express=require('express');
const signin1Router = express.Router();
function router(nav){
    
    signin1Router.get('/',function(req,res){
    
        res.render("signin1");
            
        
        })
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
    // authRouter.get('/:id',function(req,res){
    //     const id=req.params.id
    //     res.render('book',{
    //         nav,
    //             title:'Library',
    //             book:books[id]
      
    
    //     });
    // });
    return signin1Router;
}



module.exports = router;