
const express=require('express');
const addbooksRouter = express.Router();
function router(nav){


    
    
    addbooksRouter.get('/',function(req,res){
    
        res.render("addbooks",
            {
                nav,
                title:'Library',
                
            });
        
        });
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
    
    return addbooksRouter;
}



module.exports = router;