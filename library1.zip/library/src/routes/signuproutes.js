
const express=require('express');
const signup1Router = express.Router();
function router(nav){


    
    
    signup1Router.get('/',function(req,res){
    
        res.render("signup1");
            
        
        });
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
   
    return signup1Router;
}



module.exports = router;