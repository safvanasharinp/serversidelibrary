
const express=require('express');
const authRouter = express.Router();
function router(nav){


    var authors = [
        {
            //title:'tom and jerry',
            author:'joseph barbera',
            //genre:'cartoon',
            img:"tom.png"
        },
        {
           // title:'harry potter',
            author:'J K Rowling',
           // genre:'fantasy',
            img:"harry.jfif"
        },
        {
           // title:'paathummayude aadu',
            author:'vaikom muhammed basheer',
           // genre:'drama',
            img:"basheer.jfif"
        }
    ]
    
    authRouter.get('/',function(req,res){
    
        res.render("authors",
            {
                nav,
                title:'Library',
                authors
            });
        
        });
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
    authRouter.get('/:id',function(req,res){
        const id=req.params.id
        res.render('author',{
            nav,
                title:'Library',
                author:authors[id]
      
    
        });
    });
    return authRouter;
}



module.exports = router;