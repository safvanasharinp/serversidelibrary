const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/library');
const Schema=mongoose.Schema;


const signinschema=new Schema({
    authority:String,
    email:String,
    phone:String,
    psw:String,
    
});

var signindata=mongoose.model('signindata',signinschema);

module.exports=signindata;