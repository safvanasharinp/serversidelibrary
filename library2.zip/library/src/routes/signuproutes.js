
const express=require('express');
const signup1Router = express.Router();


const signupdata=require('../model/signupdata')

function router(nav){


    
    
    signup1Router.get('/',function(req,res){
    
        res.render("signup1");
            
        
        });

        signup1Router.post('/success',function(req,res){
            var item={
            authority:req.body.authority,
            email:req.body.email,
            phone:req.body.phone,
            psw:req.body.psw,
            pswrepeat:req.body.pswrepeat
            }

           var sign=signupdata(item) 
            sign.save();//saving to db
            res.redirect('/signin1');
         });

    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
   
    return signup1Router;
}



module.exports = router;