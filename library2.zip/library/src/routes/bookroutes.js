
const express=require('express');
const booksRouter = express.Router();

const bookdata=require('../model/bookdata');


function router(nav){


    // var books = [
    //     {
    //         title:'tom and jerry',
    //         author:'joseph barbera',
    //         genre:'cartoon',
    //         img:"tom.png"
    //     },
    //     {
    //         title:'harry potter',
    //         author:'J K Rowling',
    //         genre:'fantasy',
    //         img:"harry.jfif"
    //     },
    //     {
    //         title:'paathummayude aadu',
    //         author:'vaikom muhammed basheer',
    //         genre:'drama',
    //         img:"basheer.jfif"
    //     }
    // ]
    
    booksRouter.get('/',function(req,res){
        bookdata.find()
        .then(function(books){

            res.render("books",
            {
                nav,
                title:'Library',
                books
            });
        
        })

        });
        
    
        
    booksRouter.get('/:id',function(req,res){
        const id=req.params.id
        bookdata.findOne({_id:id})
        .then(function(book){


            res.render('book',{
                nav,
                title:'Library',
                book
      
    
        });
        })
       
    });


  
     booksRouter.post('/delete',function(req,res){
                const id=req.body.id;
            bookdata.deleteOne({_id:id})
            .then(function(){
                    // res.render("books",{
                    //     nav,
                    //     title:"books",
                    //     book
                    res.redirect('/books');
            
               });
                
              //  })
        
       // 
     });
     booksRouter.post('/:id/delete',function(req,res){
        const id=req.body.id;
    bookdata.deleteOne({_id:id})
    .then(function(){
            // res.render("books",{
            //     nav,
            //     title:"books",
            //     book
            res.redirect('/books');
    
       });
        
      //  })

// 
});



     booksRouter.post('/edit',function(req,res){
        const id=req.body.id;
       
        bookdata.findOne({_id:id})
        .then(function(book){


            res.render('edit',{
                nav,
                title:'edit book',
                book
      
    
        });

        })
       
    });


    // booksRouter.get('/update',function(req,res){
    //       const id=req.params.id;
             
    //     bookdata.findOneAndUpdate({_id:id},{"$set":{title:req.params.title,author:req.params.author,
    //     genre:req.params.genre,image:req.params.image}})
    //     .then(function(book){
    //         book
    //         book.save()
    //         res.redirect('/books');
    
    //    });
    // //    var book=bookdata(item) 
    // //     book.save();//saving to db
    //   //  res.redirect('/books');
    //  });


    booksRouter.post('/update',function(req,res){
        var item={
            title:req.body.name,
            author:req.body.author,
            genre:req.body.author,
            image:req.body.image
        }
        var update=bookdata.findByIdAndUpdate(req.body.id,item);
        update.exec(function(err,data){
            if(err) throw err;
            bookdata.find()
            .then(function(books){
                res.render("books",{
                    nav,
                    title:"books",
                    books
                })
            })
        })
    })





    return booksRouter;
}



module.exports = router;