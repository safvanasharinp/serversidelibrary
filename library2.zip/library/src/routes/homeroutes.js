
const express=require('express');
const homeRouter = express.Router();
function router(nav){


    // var books = [
    //     {
    //         title:'tom and jerry',
    //         author:'joseph barbera',
    //         genre:'cartoon',
    //         img:"tom.png"
    //     },
    //     {
    //         title:'harry potter',
    //         author:'J K Rowling',
    //         genre:'fantasy',
    //         img:"harry.jfif"
    //     },
    //     {
    //         title:'paathummayude aadu',
    //         author:'vaikom muhammed basheer',
    //         genre:'drama',
    //         img:"basheer.jfif"
    //     }
    // ]
    
    homeRouter.get('/',function(req,res){
    
        res.render("home",
            {
                nav,
                title:'Library',
                
            });
        
        });
    
        // booksRouter.get('/single',function(req,res){
        //     res.send("hai i am a single book");
        // });
   
    return homeRouter;
}



module.exports = router;